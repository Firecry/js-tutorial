var canvas = document.querySelector('canvas');

canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

var c = canvas.getContext('2d');

// Background Color
c.fillStyle = "#222"
c.fillRect(0, 0, canvas.width, canvas.height);


// // Cube
// c.fillStyle = "#f23";
// c.fillRect(100, 100, 100, 100);
// c.fillStyle = "#f90"
// c.fillRect(400, 100, 100, 100);
// c.fillStyle = "#add999"
// c.fillRect(300, 300, 100, 100);
// console.log(canvas);

// // Line
// c.beginPath();
// c.moveTo(50, 300);
// c.lineTo(300, 100);
// c.lineTo(400, 300);
// c.strokeStyle = "#dd1baa";
// c.stroke();

// // Arc / Circle
// c.beginPath();
// c.arc(200, 300, 30, 0, Math.PI * 2, false);
// c.strokeStyle = "blue"
// c.stroke();

// // Circles in loop
// // setInterval(()=>{
// for(let i = 0; i < 3; i++){

//     var x = Math.random() * canvas.width;
//     var y = Math.random() * canvas.height;
//     var color = `hsl(${Math.floor(Math.random() * 300)}, 100%, 50%`;
//     console.log(color);

//     c.beginPath();
//     c.arc(x, y, Math.random() * 50, 0, Math.PI * 2, false);
//     c.strokeStyle = color;
//     c.stroke();
// }
// // }, 150)

// Mouse Listener

var mouse = {
    x: undefined,
    y: undefined
}

var maxRadius = 40;
// var minRadius = 2;

window.addEventListener('mousemove', (e)=>{
    mouse.x = e.x;
    mouse.y = e.y;
})

window.addEventListener('resize', ()=>{
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    init();
})

// Animated Circle
function Circle(x, y, dx, dy, radius, color){
    this.x = x;
    this.y = y;
    this.dx = dx;
    this.dy = dy;
    this.radius = radius;
    this.minRadius = radius;
    this.color = color;

    this.draw = ()=>{
        c.beginPath();
        c.fillStyle = this.color;
        c.arc(this.x, this.y, this.radius, 0, Math.PI * 2, false);
        // c.strokeStyle = '#222';
        c.stroke();
        c.fill();
    }

    this.update = ()=>{
        if(this.x + this.radius > canvas.width || this.x - this.radius < 0){
            this.dx = -this.dx;
            circleArray.push(new Circle(this.x, this.y, (Math.random() - .5), (Math.random() - .5), this.radius, `hsl(${Math.floor(Math.random() * 300)}, 100%, 50%`));
        }
        if(this.y + this.radius > canvas.height || this.y - this.radius < 0){
            this.dy = -this.dy;
        }
    
        this.x += this.dx;
        this.y += this.dy;

        // interactivity
        if((mouse.x - this.x < 50 && mouse.x - this.x > -50)&&(mouse.y - this.y < 50 && mouse.y - this.y > -50)){
            if(this.radius < maxRadius){
                this.radius += 1;
            }
        }
        else if(this.radius > this.minRadius){
            this.radius -= 1;
        }

        this.draw();
    }
}

var circleArray = []

function init(){
    for(let i = 0; i < 2; i++){
        var x = Math.floor(Math.random() * (canvas.width - radius * 4) + radius);
        var y = Math.floor(Math.random() * (canvas.height - radius * 4) + radius);
        var dx = (Math.random() - .5);
        var dy = (Math.random() - .5);
        var radius = Math.random() * 8 + 2;
        var color = `hsl(${Math.floor(Math.random() * 300)}, 100%, 50%`;

        circleArray.push(new Circle(x, y, dx, dy, radius, color));
    }
}

function animate(){
    requestAnimationFrame(animate);
    c.clearRect(0, 0, canvas.width, canvas.height);

    c.fillStyle = '#222';
    c.fillRect(0, 0, canvas.width, canvas.height);

    for (let i = 0; i < circleArray.length; i++){
        circleArray[i].update();
    }

    // Mouse Position

    // c.fillStyle = "#f23";
    // c.fillRect(mouse.x, mouse.y, 20, 20);
}

init();

animate();